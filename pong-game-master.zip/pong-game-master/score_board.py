from turtle import Turtle


class Scoreboard(Turtle):
    def __init__(self, x, y):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.x_cod = x
        self.y_cod = y
        self.goto(x, y)
        self.color('white')
        self.score = 0
        self.print_score()

    def print_score(self):
        self.clear()
        self.goto(self.x_cod, self.y_cod)
        self.write(f"{self.score}", True, align="center", font=("Courier", 80, "normal"))



    # def draw_line(self, start_y, end_y):
    #     """Draw a vertical dotted line in the center."""
    #     self.penup()
    #     self.goto(0, start_y)  # Starting point of the line
    #     self.setheading(270)  # Point downward
    #
    #     while self.ycor() > end_y:  # Draw until reaching the end
    #         self.pendown()
    #         self.forward(10)  # Draw a small segment
    #         self.penup()
    #         self.forward(10)  # Leave a gap

