from turtle import Screen,Turtle
from players import Paddle
from pong import Pong
from score_board import Scoreboard
import time


def draw_line(timmy, y1, y2):
    timmy.penup()
    timmy.color("white")
    timmy.setheading(90)
    timmy.goto(0, y1)
    for i in range(y1, y2):
        timmy.pendown()
        timmy.forward(50)
        timmy.penup()
        timmy.forward(50)


SPEED = 0.1
screen = Screen()
screen.bgcolor("Black")
screen.setup(800, 600)
screen.title("Pong Game")
screen.tracer(0)
tim = Turtle()

l_paddle = Paddle(-370, 0)
r_paddle = Paddle(370, 0)
l_score = Scoreboard(-100, 200)
r_score = Scoreboard(100, 200)
pong = Pong()
draw_line(tim, -300, 300)
game_on = True


def pause_game():
    global game_on
    game_on = False


def play_game():
    global game_on
    game_on = True


screen.listen()
screen.onkey(l_paddle.move_up, "Up")
screen.onkey(l_paddle.move_down, "Down")
screen.onkey(r_paddle.move_up, "w")
screen.onkey(r_paddle.move_down, "s")
# screen.onkey(pause_game, " ")
# screen.onkey(play_game, "p")
screen.update()

while game_on:
    time.sleep(pong.p_speed)
    screen.update()
    pong.move()
    if pong.ycor() > 280 or pong.ycor() < -280:
        pong.bounce_y()

    elif pong.xcor() > 400:
        pong.refresh()
        l_score.score += 1
        l_score.print_score()

    elif pong.xcor() < -400:
        pong.refresh()
        r_score.score += 1
        r_score.print_score()

    elif (pong.distance(l_paddle) < 45 and pong.xcor() < -350) or (pong.distance(r_paddle) < 45 and pong.xcor() > 350):
        pong.bounce_x()

    # print(l_score.score)
    # print(r_score.score)

screen.exitonclick()
