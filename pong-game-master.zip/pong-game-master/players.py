from turtle import Turtle


class Paddle(Turtle):
    def __init__(self, x_cod, y_cod):
        super().__init__()
        self.color('White')
        self.penup()
        self.shape("square")
        self.shapesize(stretch_wid=3, stretch_len=1)
        self.goto(x_cod, y_cod)

    def move_up(self):
        new_y = self.ycor() + 20
        self.goto(x=self.xcor(), y=new_y)

    def move_down(self):
        new_y = self.ycor() - 20
        self.goto(x=self.xcor(), y=new_y)
